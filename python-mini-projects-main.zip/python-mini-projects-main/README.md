# python-mini-projects
Python projects for beginners
