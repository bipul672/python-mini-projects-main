# Simple Calculator using Python

Here's a quick example of how you might set this up:
1. Open Command Prompt (you can search for "cmd" in the start menu).

2. Use the cd command to navigate to your script's directory:
```
cd C:\Users\Dubey\Bipul Kumar\Python Mini Projects\Simple_Calculator
```
3. Run your Python script:
```bash
python calculator.py
```

## Available Operations 
Addition (1): Sum of multiple numbers. <br>
Subtraction (2): Difference between two numbers. <br>
Multiplication (3): Product of multiple numbers. <br>
Division (4): Quotient of two numbers. <br>
Average (5): Average of multiple numbers.

### Learn more on YouTube Channel: www.youtube.com/@RishabhMishraOfficial 
